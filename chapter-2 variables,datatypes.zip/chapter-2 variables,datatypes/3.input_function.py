# a = input("Enter Your Name : ")
# print(a)
# print(type(a))
# Everything taken from input function is of string type
# It should be converted to required datatype after taking the input

b = int(input("Enter a number: "))
print(b)
print(type(b))
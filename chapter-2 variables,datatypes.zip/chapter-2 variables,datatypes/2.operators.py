# print("The value of 3 + 4 is ",3+4)
# # Assignment operators =, +=, -=  etc.
# # Comparision operators

# b = (12==3)
# print (b)

#Type casting
a="234"
b = int (a)
print(b+5)
print (type(a))
c = str(b)
print(type(c))
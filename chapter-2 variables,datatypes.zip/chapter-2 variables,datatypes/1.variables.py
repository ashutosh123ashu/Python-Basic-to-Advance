# a = "harry"
# b = 345
c = 45.32
# print(a,b,c)
# # Boolean variables
D = True
# print (D)
# Printing datatype of a variable
print(type(D))
print(type(c))